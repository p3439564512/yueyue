# 聊天 APP（WebView 套壳 · GitHub 云端打包）

一个安卓 WebView 壳，加载内置的 `chat-app.html` 聊天网页；接口、人设、记忆都保存在本机。
本仓库已配好 GitHub Actions，推送到仓库后由 GitHub 云端自动编译出 debug APK，**本地不需要装 Android Studio、JDK 或 SDK**。

## 一、你需要准备
- 一个免费 GitHub 账号：https://github.com （点右上角 Sign up 注册，已注册直接 Sign in）

## 二、上传仓库（最简单：网页上传，不用装 git）
1. 打开 https://github.com 登录后，右上角 **+ → New repository**。
2. 仓库名随便填，例如 `chatapp`；选 **Public（公开）**（公开仓库 Actions 打包免费不限量）；勾选 **Add a README** 可不勾；点 **Create repository**。
3. 进入新建仓库，点 **Add file → Upload files**。
4. 把本压缩包解压后的**全部文件和文件夹**拖进去（保持目录结构不变，关键是 `.github`、`app` 两个文件夹在根目录）。
5. 页面底部点 **Commit changes**。

## 三、等云端自动打包
1. 上传提交后，点仓库顶部 **Actions** 标签。
2. 会看到一条 **Build Debug APK** 的运行记录，黄色圆点表示编译中，绿色对勾表示成功（首次约 5～15 分钟）。
3. 点进这条运行记录，拉到页面底部 **Artifacts** 区域，下载 `chat-app-debug`，解压即得到 APK。

> 如果运行记录是红色叉号：点进去看红色步骤的报错，把报错内容发回给我排查。

## 四、安装到手机
1. 把 APK 传到红米 K80U（微信/QQ 传文件、数据线、网盘均可）。
2. 点 APK 安装，系统提示「未知来源」时允许本次安装。
3. 打开 APP，先点右上角 ⚙ 填接口地址、API Key、模型名；角色预设选「大肥鱼」，人设可粘贴自己的版本。

## 五、目录结构
```
gh-android-app/
├── .github/workflows/build-apk.yml   # 云端自动打包脚本
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/chat-app.html       # 聊天网页（含人设预设、记忆导入导出）
│       ├── java/com/example/chatapp/MainActivity.java
│       └── res/values/strings.xml
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 说明与限制
- 打出的是 **debug 签名包**，自己手机安装够用；上架应用商店才需要正式签名和 keystore。
- 记忆、配置存在 APP 本地（WebView localStorage），卸载 APP 会清空；可用网页里的「导出 JSON」先备份。
- 网页里的「导出 JSON」在 WebView 内受浏览器下载限制；如需备份，建议在电脑浏览器打开 `chat-app.html` 操作。
